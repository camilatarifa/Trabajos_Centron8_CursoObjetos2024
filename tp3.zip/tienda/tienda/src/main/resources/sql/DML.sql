-- Active: 1714155149639@@127.0.0.1@3306
    use tienda;

INSERT INTO sucursales (localidad, calle, pagos, horarios)
VALUES
    ('Buenos Aires', 'Avenida Corrientes', 'EFECTIVO, TARJETA_CRÉDITO', 'MAÑANA, TARDE'),
    ('Córdoba', 'Calle San Martín', 'EFECTIVO, TARJETA_DÉBITO', 'TARDE, NOCHE'),
    ('Rosario', 'Bulevar Oroño', 'TARJETA_CRÉDITO, TRANSFERENCIA', 'MAÑANA, NOCHE'),
    ('Mendoza', 'Patricias Mendocinas', 'EFECTIVO, TARJETA_CRÉDITO', 'MAÑANA, TARDE'),
    ('Mar del Plata', 'Calle Güemes', 'EFECTIVO, TARJETA_DÉBITO', 'TARDE, NOCHE'),
    ('Tucumán', 'Avenida Alem', 'TARJETA_CRÉDITO, TRANSFERENCIA', 'MAÑANA, NOCHE'),
    ('Salta', 'Calle Caseros', 'EFECTIVO, TARJETA_DÉBITO', 'MAÑANA, TARDE'),
    ('Neuquén', 'Avenida Argentina', 'TARJETA_CRÉDITO, TRANSFERENCIA', 'TARDE, NOCHE'),
    ('Río Gallegos', 'Calle Pasteur', 'EFECTIVO, TARJETA_DÉBITO', 'MAÑANA, NOCHE'),
    ('Posadas', 'Avenida Roque Sáenz Peña', 'TARJETA_CRÉDITO, TRANSFERENCIA', 'TARDE, NOCHE');

INSERT INTO comics (nombre, autor, precios, idsucursales) 
VALUES
-- Mangas/Cómics japoneses
('Berserk', 'Kentaro Miura', 2500.00, 1),
('Chainsaw Man', 'Tatsuki Fujimoto', 2000.00, 2),
('One Piece', 'Eiichiro Oda', 2800.00, 3),
('Naruto', 'Masashi Kishimoto', 2300.00, 4),
('Dragon Ball', 'Akira Toriyama', 2400.00, 5),
('Attack on Titan', 'Hajime Isayama', 2200.00, 6),
('Fullmetal Alchemist', 'Hiromu Arakawa', 2100.00, 7),
('Jojo''s Bizarre Adventure', 'Hirohiko Araki', 2600.00, 8),
('Hunter x Hunter', 'Yoshihiro Togashi', 2400.00, 9),
('Death Note', 'Tsugumi Ohba', 2100.00, 10),
('Bleach', 'Tite Kubo', 2300.00, 1),
('My Hero Academia', 'Kohei Horikoshi', 2200.00, 2),
('Tokyo Ghoul', 'Sui Ishida', 2400.00, 3),
('Haikyuu!!', 'Haruichi Furudate', 2100.00, 4),
('Slam Dunk', 'Takehiko Inoue', 2500.00, 5),
('Rurouni Kenshin', 'Nobuhiro Watsuki', 2300.00, 6),
('Vagabond', 'Takehiko Inoue', 2800.00, 7),
('Demon Slayer', 'Koyoharu Gotouge', 2000.00, 8),
('Mob Psycho 100', 'ONE', 2100.00, 9),
('Vinland Saga', 'Makoto Yukimura', 2400.00, 10),
('Akira', 'Katsuhiro Otomo', 2600.00, 1),
('Monster', 'Naoki Urasawa', 2500.00, 2),
('Oyasumi Punpun', 'Inio Asano', 2300.00, 3),
('Blame!', 'Tsutomu Nihei', 2400.00, 4),
('Psyren', 'Toshiaki Iwashiro', 2200.00, 5),
('Gantz', 'Hiroya Oku', 2700.00, 6),
-- Cómics clásicos americanos
('Superman', 'Jerry Siegel', 1500.00, 7),
('Batman', 'Bob Kane', 1800.00, 8),
('Spider-Man', 'Stan Lee', 1600.00, 9),
('X-Men', 'Stan Lee', 1700.00, 10),
('Captain America', 'Joe Simon', 1500.00, 1),
('The Fantastic Four', 'Stan Lee', 1600.00, 2),
('Hulk', 'Stan Lee', 1700.00, 3),
('Wonder Woman', 'William Moulton Marston', 1800.00, 4),
('The Avengers', 'Stan Lee', 1600.00, 5),
('Archie', 'Bob Montana', 1500.00, 6);