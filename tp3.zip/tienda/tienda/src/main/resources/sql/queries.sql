-- Active: 1714155149639@@127.0.0.1@3306@tienda
use tienda;
SELECT * FROM sucursales WHERE activo = true;
SELECT * FROM comics WHERE activo = true;
SELECT s.localidad, s.horarios FROM sucursales s INNER JOIN comics c ON s.id = c.idsucursales;
UPDATE sucursales SET horarios = 'TARDE' WHERE id = 3;
DELETE FROM comics WHERE id = 32;  
SELECT nombre, autor FROM comics WHERE activo = true ORDER BY nombre ASC;
