-- Active: 1714155149639@@127.0.0.1@3306@tienda

     drop database if exists tienda;
create database tienda;
use tienda;
drop table if exists comics;
drop table if exists sucursales;
create table sucursales(
    id int auto_increment primary key,
    localidad varchar(25) not null check(length(localidad)>=5),
    calle varchar(25) not null check(length(calle)>=5),
    pagos  varchar(50) not null check(length(pagos)>=7),
    horarios varchar(50) not null check (length(horarios)>=5),
    activo boolean default true
);
create table comics (
    id int auto_increment primary key,
    nombre varchar(25) not null check(length(nombre)>=3),
    autor varchar(25) not null check(length(autor)>=3),
    precios int not null check(precios>=1200 and precios<=120000),
    idsucursales int not null,
    activo boolean default true
);
alter table comics
    add constraint FK_Comics_Sucursales
    foreign key (idSucursales) 
    references sucursales(id);