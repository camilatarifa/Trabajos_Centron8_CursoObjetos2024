package ar.org.centro8.entities;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Sucursales {
    private int id;
    private String localidad;
    private String calle;
    private String pagos;
    private String horarios;
}
