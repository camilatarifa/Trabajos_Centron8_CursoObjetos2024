package ar.org.centro8.repositories;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;

import ar.org.centro8.connectors.Connector;

import ar.org.centro8.entities.Sucursales;



public class SucursalesRepository {
     private Connection conn=Connector.getConnection();

    public void save(Sucursales Sucursales){
        if(Sucursales==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into Sucursales (localidad, calle, pagos, horarios)",
            PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setString(1, Sucursales.getLocalidad());
            ps.setString(2, Sucursales.getCalle());
            ps.setString(3, Sucursales.getPagos());
            ps.setString(4, Sucursales.getHorarios());          
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) Sucursales.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Sucursales Sucursales){
        if(Sucursales==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "delete from Sucursal where id=?")){
            ps.setInt(1, Sucursales.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Sucursales>getAll(){
        List<Sucursales> list=new ArrayList();
        try (ResultSet rs=conn
                                .createStatement()
                                .executeQuery("select * from Sucursal")){
            while(rs.next()){
                list.add(new Sucursales(
                                    rs.getInt("id"), 
                                    rs.getString("localidad"), 
                                    rs.getString("calle"), 
                                    rs.getString("pagos"), 
                                    rs.getString("horarios") 
                                    ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Sucursales getById(int id){
        return getAll()
                        .stream()
                        .filter(Sucursales->Sucursales.getId()==id)
                        .findFirst()
                        .orElse(new Sucursales());
    }

    public List<Sucursales> getSucursales(String localidad){
        if(localidad==null) return new ArrayList();
        return getAll()
                        .stream()
                        .filter(Sucursales->Sucursales
                                            .getLocalidad()
                                            .toLowerCase()
                                            .contains(localidad.toLowerCase()))
                        .toList();
    }
}
