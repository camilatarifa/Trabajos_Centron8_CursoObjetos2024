package ar.org.centro8.test;
import java.sql.ResultSet;
import java.time.Duration;
import java.time.LocalDateTime;

import ar.org.centro8.connectors.Connector;




public class TestConnector {
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_RESET = "\u001B[0m";
    public static void main(String[] args) {
        LocalDateTime inicio=LocalDateTime.now();
        try (ResultSet rs = Connector
                .getConnection()
                .createStatement()
                .executeQuery("select version()")) {
            if (rs.next()) {
                System.out.println(rs.getString(1));
                System.out.println(ANSI_GREEN+"OK - Se conecto a la BD");
                LocalDateTime fin=LocalDateTime.now();
                Duration duration=Duration.between(inicio, fin);
                long segundos=duration.toSeconds();
                if(segundos<1){
                    System.out.println(ANSI_GREEN+"OK - Tiempo de conexión menor a 1 segundo.");
                }else{
                    System.out.println(ANSI_RED+"Error - Tiempo de conexión "+segundos+" segundos.");
                }
            } else {
                System.out.println(ANSI_RED+"Error - No se conecto a la BD");
            }
        } catch (Exception e) {
            System.out.println(e);
            System.out.println(ANSI_RED+"Error - No se conecto a la BD");
        }
        System.out.println(ANSI_RESET);
    }
}
