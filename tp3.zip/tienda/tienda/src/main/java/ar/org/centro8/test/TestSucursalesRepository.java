package ar.org.centro8.test;

import ar.org.centro8.entities.Sucursales;
import ar.org.centro8.repositories.SucursalesRepository;




public class TestSucursalesRepository {
    public static void main(String[] args) {
    SucursalesRepository SucursalesRepository=new SucursalesRepository();

    Sucursales sucursal=new Sucursales(100, "Quilmes",
     "Avenida Bernardo de Irigoyen", 
     "EFECTIVO, TARJETA_DÉBITO", 
     "MAÑANA, NOCHE");
     SucursalesRepository.save(sucursal);
    System.out.println(sucursal);
                    
    System.out.println(SucursalesRepository.getById(10));

    SucursalesRepository.remove(SucursalesRepository.getById(26));


    SucursalesRepository.getSucursales("Quilmes").forEach(System.out::println);

    SucursalesRepository.getAll().forEach(System.out::println);
 
}
}
